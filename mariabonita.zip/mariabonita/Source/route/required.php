<?php

return ["Database"         => "/mariabonita/Source/dba/dbConn.php",
        "classNewUpdCliente"  => "/mariabonita/Source/dba/classNewUpdCliente.php",
        "classDelCliente"  => "/mariabonita/Source/dba/classDelCliente.php",
        "classSelCliente"  => "/mariabonita/Source/dba/classSelCliente.php",
        "fnExibir"         => "/mariabonita/Source/app/fnExibir.php",
        "fnTable"          => "/mariabonita/Source/app/fnTable.php",
        "fnCEP"            => "/mariabonita/Source/app/fnCEP.php"
        ]
?>