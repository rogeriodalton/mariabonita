<?php

return ["Home"              => "/mariabonita/Source/View/home.php",
        "NotFound"          => "/mariabonita/Source/View/PageNotFound.php",
        "sobre"             => "/mariabonita/Source/View/About.php",
        "ListarClientes"    => "/mariabonita/Source/View/ListarClientes.php",
        "GravaCliente"      => "/mariabonita/Source/app/ClienteGrava.php",
        "CadastroCliente"   => "/mariabonita/Source/view/CadastroCliente.php",
        "ClienteExcluir"    => "/mariabonita/Source/app/ClienteExcluir.php"
       ];
        
?>
