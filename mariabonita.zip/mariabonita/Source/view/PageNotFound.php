<?php
echo '<h1>Caminho ou Página não encontrada.</h1>';
?>