Projeto experimental PHP

Para instalar, importar banco de dados mariabonita.sql
copiar todo sistema para C:\mariabonita
a subpasta apache_public, copiar para htdocs do Apache, ali encontram-se o index.php, .htaccess e outros

